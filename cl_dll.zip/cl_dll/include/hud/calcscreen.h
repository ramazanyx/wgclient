#ifndef CALCSCREEN_H
#define CALCSCREEN_H

int CalcScreen(const float in[3], float out[2]);

#endif